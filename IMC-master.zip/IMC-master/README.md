<h1 align="center">
    Cálculo de IMC
</h1>

<h4 align="center">
  Esse aplicativo foi desenvolvido com o simples objetivo de calcular o IMC (Índice de Massa Corporal) de uma pessoa.
</h4>

<p align="center">
    <img alt="IMC APP - Initial Screen" src="https://user-images.githubusercontent.com/41929586/83837690-720a3700-a6cd-11ea-9abc-8f7dfcb8d489.png"/>
    <img alt="IMC APP - Filling the Form" src="https://user-images.githubusercontent.com/41929586/83837693-746c9100-a6cd-11ea-8ac1-940f656d9864.png"/>
    <img alt="IMC APP - Result Screen" src="https://user-images.githubusercontent.com/41929586/83837695-76ceeb00-a6cd-11ea-9e57-b1c7b7a06c01.png"/>
</p>
<p align="center">
  <a href="https://drive.google.com/drive/folders/1U5X1xgt-JwiUgW72Ft6ORi66QI8wBCYf?usp=sharing" target="_blank">Download the .apk Here</a>
</p>

## :rocket: Technologies

This project was developed with the following technologies:

-  [Android](https://www.android.com/intl/pt-BR_br/)
-  [Kotlin](https://kotlinlang.org/)
-  [Android Studio](https://developer.android.com/studio)

Made by [Walter Junior!](https://www.linkedin.com/in/walter-paes/)
